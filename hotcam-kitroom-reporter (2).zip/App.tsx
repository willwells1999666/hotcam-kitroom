import React, { useState, useEffect } from 'react';
import { AppView, KitReport } from './types';
import { ReportForm } from './components/ReportForm';
import { QRCodeGenerator } from './components/QRCodeGenerator';
import { ReportsList } from './components/ReportsList';
import { CONFIG } from './constants';
import { CheckCircle2, ClipboardList, LayoutDashboard } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.DASHBOARD);
  const [lastReport, setLastReport] = useState<KitReport | null>(null);
  const [allReports, setAllReports] = useState<KitReport[]>([]);

  // Load reports on mount and when hash changes
  useEffect(() => {
    const reports = JSON.parse(localStorage.getItem('hotcam_reports') || '[]');
    setAllReports(reports);

    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash === '#/report') {
        setView(AppView.REPORT_FORM);
      } else if (hash === '#/history') {
        setView(AppView.HISTORY);
      } else {
        setView(AppView.DASHBOARD);
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleReportSuccess = (report: KitReport) => {
    setLastReport(report);
    // Refresh the full list
    const reports = JSON.parse(localStorage.getItem('hotcam_reports') || '[]');
    setAllReports(reports);
    setView(AppView.SUCCESS);
  };

  const handleDeleteReport = (id: string) => {
    const updatedReports = allReports.filter(r => r.id !== id);
    setAllReports(updatedReports);
    localStorage.setItem('hotcam_reports', JSON.stringify(updatedReports));
  };

  const handleUpdateStatus = (id: string, status: KitReport['status']) => {
    const updatedReports = allReports.map(r => 
      r.id === id ? { ...r, status } : r
    );
    setAllReports(updatedReports);
    localStorage.setItem('hotcam_reports', JSON.stringify(updatedReports));
  };

  return (
    <div className="min-h-screen warehouse-bg text-white selection:bg-red-500/30 font-helvetica">
      {/* Navigation Header */}
      <header className="fixed top-0 left-0 right-0 h-20 bg-black/40 backdrop-blur-xl border-b border-white/5 z-50 px-6 flex items-center justify-between">
        <div className="flex items-center gap-4 cursor-pointer" onClick={() => window.location.hash = ''}>
          <span className="text-2xl font-black tracking-tighter text-white">
            HOTCAM <span className="text-red-600">KITROOM</span>
          </span>
        </div>
        
        <div className="flex items-center gap-4">
          {view !== AppView.HISTORY && (
            <button 
              onClick={() => window.location.hash = '#/history'}
              className="px-4 py-2 bg-red-600 hover:bg-white hover:text-black text-white rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2"
            >
              <ClipboardList size={14} /> Reports Board
            </button>
          )}
          {view !== AppView.DASHBOARD && (
            <button 
              onClick={() => window.location.hash = ''}
              className="text-slate-400 hover:text-white flex items-center gap-2 text-sm font-bold uppercase tracking-wider transition-colors"
            >
              <LayoutDashboard size={18} /> Hub
            </button>
          )}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="pt-32 pb-12 px-6">
        <div className="max-w-5xl mx-auto">
          
          {view === AppView.DASHBOARD && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
              <div className="text-center mb-16 space-y-6">
                <h1 className="text-5xl sm:text-7xl font-bold text-white tracking-tighter leading-none italic uppercase drop-shadow-2xl">
                  Need Something <br />
                  <span className="text-red-600">that we haven't got?</span>
                </h1>
                <p className="text-xl sm:text-2xl text-slate-300 max-w-3xl mx-auto leading-relaxed font-medium">
                  Submit a report of missing accessories or consumables to notify U9 team.
                </p>
                
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
                  <button 
                    onClick={() => window.location.hash = '#/report'}
                    className="group relative inline-flex items-center justify-center px-12 py-6 text-xl font-black uppercase tracking-widest text-white transition-all bg-red-600 rounded-2xl hover:bg-white hover:text-black hover:scale-105 active:scale-95 shadow-2xl shadow-red-600/20 w-full sm:w-auto"
                  >
                    New Report Form
                    <span className="ml-3 group-hover:translate-x-2 transition-transform">→</span>
                  </button>
                  <button 
                    onClick={() => window.location.hash = '#/history'}
                    className="group inline-flex items-center justify-center px-10 py-6 text-lg font-black uppercase tracking-widest text-white transition-all bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 w-full sm:w-auto"
                  >
                    View Status Board
                  </button>
                </div>
              </div>

              <div className="flex justify-center">
                <QRCodeGenerator />
              </div>
            </div>
          )}

          {view === AppView.REPORT_FORM && (
            <div className="animate-in zoom-in-95 duration-300">
              <ReportForm onSuccess={handleReportSuccess} />
            </div>
          )}

          {view === AppView.HISTORY && (
            <ReportsList 
              reports={allReports} 
              onBack={() => window.location.hash = ''}
              onDelete={handleDeleteReport}
              onUpdateStatus={handleUpdateStatus}
            />
          )}

          {view === AppView.SUCCESS && (
            <div className="max-w-md mx-auto text-center py-12 animate-in fade-in slide-in-from-top-4">
              <div className="inline-flex items-center justify-center w-24 h-24 bg-green-500/10 text-green-500 rounded-full mb-8 border border-green-500/20">
                <CheckCircle2 size={56} />
              </div>
              <h2 className="text-4xl font-black text-white mb-4 uppercase italic">Report Logged!</h2>
              <p className="text-slate-400 mb-10 text-lg leading-relaxed">
                Management has been notified of the missing <span className="text-red-600 font-black">{lastReport?.itemName}</span>. 
                The entry has been added to the board.
              </p>
              <div className="space-y-4">
                <button 
                  onClick={() => window.location.hash = '#/history'}
                  className="w-full bg-red-600 hover:bg-white hover:text-black text-white font-black py-5 rounded-2xl transition-all uppercase tracking-widest shadow-xl shadow-red-600/10"
                >
                  View on Board
                </button>
                <button 
                  onClick={() => window.location.hash = ''}
                  className="w-full bg-white/5 hover:bg-white/10 text-white font-black py-5 rounded-2xl transition-all uppercase tracking-widest"
                >
                  Back to Dashboard
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className="py-12 border-t border-white/5 text-center opacity-40">
        <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">
          &copy; {new Date().getFullYear()} {CONFIG.COMPANY_NAME} • LOGISTICS SYSTEMS v2.0
        </p>
      </footer>
    </div>
  );
};

export default App;