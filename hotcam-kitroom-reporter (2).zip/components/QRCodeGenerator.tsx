import React, { useEffect, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Share2, Printer, Copy, Check } from 'lucide-react';

export const QRCodeGenerator: React.FC = () => {
  const [reportUrl, setReportUrl] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const url = `${window.location.origin}${window.location.pathname}#/report`;
    setReportUrl(url);
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(reportUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-md border border-white/10 rounded-[2.5rem] p-10 shadow-2xl flex flex-col items-center max-w-lg w-full">
      <div className="mb-8 text-center">
        <h2 className="text-2xl font-black text-white mb-2 uppercase tracking-tight">Warehouse Quick Access</h2>
        <p className="text-slate-400 font-medium">Scan this QR code with any mobile device to start a report.</p>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-2xl mb-10 transition-all hover:scale-[1.02] duration-500 ring-4 ring-white/5">
        <QRCodeSVG 
          value={reportUrl} 
          size={240} 
          level="H"
          includeMargin={false}
          fgColor="#000000"
        />
      </div>

      <div className="w-full space-y-4">
        <div className="flex items-center gap-3 p-4 bg-black/40 rounded-2xl border border-white/5 group">
          <code className="text-xs text-slate-500 truncate flex-1 font-mono uppercase tracking-tighter">{reportUrl}</code>
          <button 
            onClick={handleCopy}
            className="text-slate-500 hover:text-red-500 transition-colors"
            title="Copy URL"
          >
            {copied ? <Check size={20} className="text-green-500" /> : <Copy size={20} />}
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={handlePrint}
            className="flex items-center justify-center gap-3 py-4 px-6 bg-white text-black hover:bg-red-600 hover:text-white rounded-2xl font-black uppercase tracking-widest transition-all active:scale-95"
          >
            <Printer size={20} /> Print
          </button>
          <button 
            onClick={handleCopy}
            className="flex items-center justify-center gap-3 py-4 px-6 bg-white/5 hover:bg-white/10 text-white rounded-2xl font-black uppercase tracking-widest transition-all active:scale-95 border border-white/5"
          >
            <Share2 size={20} /> Share
          </button>
        </div>
      </div>
    </div>
  );
};