
export const CONFIG = {
  EMAIL_RECEIVER: 'will.wells@hotcam.tv',
  COMPANY_NAME: 'Hotcam TV Kitroom',
  PRIMARY_COLOR: '#ef4444', // Red-500
  ACCENT_COLOR: '#1e293b',  // Slate-800
};

export const SYSTEM_PROMPT = `You are a professional warehouse inventory assistant for a high-end TV production kitroom. 
When a user reports a missing item, provide a very brief, professional confirmation message. 
Categorize the item (e.g., Camera, Audio, Lighting, Consumable, Grip).`;
