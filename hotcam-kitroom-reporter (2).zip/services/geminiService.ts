
import { GoogleGenAI, Type } from "@google/genai";
import { KitReport } from "../types";
import { SYSTEM_PROMPT } from "../constants";

export const processReportWithGemini = async (report: KitReport): Promise<{ summary: string; category: string }> => {
  const apiKey = process.env.API_KEY;
  
  // If API key is missing or invalid, return fallback immediately to prevent hanging
  if (!apiKey || apiKey === 'undefined' || apiKey.length < 5) {
    return {
      summary: `Missing ${report.itemName} reported by ${report.userName}.`,
      category: "General Kit"
    };
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Report Details: Item: ${report.itemName}, User: ${report.userName}, Date: ${report.date}. Please process this report.`,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            category: { type: Type.STRING }
          },
          required: ["summary", "category"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from Gemini");

    const data = JSON.parse(text);
    return {
      summary: data.summary || `Missing ${report.itemName} reported.`,
      category: data.category || "General Kit"
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    // Fallback data so the user can still send the email
    return {
      summary: `Request for ${report.itemName} has been logged.`,
      category: "Kitroom Item"
    };
  }
};
