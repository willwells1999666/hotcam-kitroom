
import React, { useState, useEffect } from 'react';
import { AppView, KitReport } from './types';
import { ReportForm } from './components/ReportForm';
import { QRCodeGenerator } from './components/QRCodeGenerator';
import { ReportsList } from './components/ReportsList';
import { CONFIG } from './constants';
import { CheckCircle2, ClipboardList, LayoutDashboard } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.DASHBOARD);
  const [lastReport, setLastReport] = useState<KitReport | null>(null);
  const [allReports, setAllReports] = useState<KitReport[]>([]);

  useEffect(() => {
    const reports = JSON.parse(localStorage.getItem('hotcam_reports') || '[]');
    setAllReports(reports);

    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash === '#/report') {
        setView(AppView.REPORT_FORM);
      } else if (hash === '#/history') {
        setView(AppView.HISTORY);
      } else {
        setView(AppView.DASHBOARD);
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleReportSuccess = (report: KitReport) => {
    setLastReport(report);
    const reports = JSON.parse(localStorage.getItem('hotcam_reports') || '[]');
    setAllReports(reports);
    setView(AppView.SUCCESS);
  };

  const handleDeleteReport = (id: string) => {
    const updatedReports = allReports.filter(r => r.id !== id);
    setAllReports(updatedReports);
    localStorage.setItem('hotcam_reports', JSON.stringify(updatedReports));
  };

  const handleUpdateStatus = (id: string, status: KitReport['status']) => {
    const updatedReports = allReports.map(r => 
      r.id === id ? { ...r, status } : r
    );
    setAllReports(updatedReports);
    localStorage.setItem('hotcam_reports', JSON.stringify(updatedReports));
  };

  return (
    <div className="min-h-screen warehouse-bg text-white selection:bg-red-500/30">
      <header className="fixed top-0 left-0 right-0 h-20 bg-black/40 backdrop-blur-xl border-b border-white/5 z-50 px-6 flex items-center justify-between">
        <div className="flex items-center gap-4 cursor-pointer" onClick={() => window.location.hash = ''}>
          <span className="text-2xl font-black tracking-tighter text-white">
            HOTCAM <span className="text-red-600">KITROOM</span>
          </span>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={() => window.location.hash = '#/history'}
            className="px-4 py-2 bg-red-600 hover:bg-white hover:text-black text-white rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2"
          >
            <ClipboardList size={14} /> Reports Board
          </button>
          {view !== AppView.DASHBOARD && (
            <button 
              onClick={() => window.location.hash = ''}
              className="text-slate-400 hover:text-white flex items-center gap-2 text-sm font-bold uppercase tracking-wider transition-colors"
            >
              <LayoutDashboard size={18} /> Hub
            </button>
          )}
        </div>
      </header>

      <main className="pt-32 pb-12 px-6">
        <div className="max-w-5xl mx-auto">
          {view === AppView.DASHBOARD && (
            <div className="text-center space-y-12">
              <div className="space-y-6">
                <h1 className="text-5xl sm:text-7xl font-bold text-white tracking-tighter leading-none italic uppercase">
                  Missing <span className="text-red-600">Inventory?</span>
                </h1>
                <p className="text-xl text-slate-300 max-w-2xl mx-auto font-medium">
                  Quick reporting for accessories and consumables.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
                  <button 
                    onClick={() => window.location.hash = '#/report'}
                    className="px-12 py-6 text-xl font-black uppercase tracking-widest text-white bg-red-600 rounded-2xl hover:bg-white hover:text-black transition-all shadow-xl shadow-red-600/20 w-full sm:w-auto"
                  >
                    Report Item
                  </button>
                </div>
              </div>
              <div className="flex justify-center">
                <QRCodeGenerator />
              </div>
            </div>
          )}

          {view === AppView.REPORT_FORM && <ReportForm onSuccess={handleReportSuccess} />}
          {view === AppView.HISTORY && (
            <ReportsList 
              reports={allReports} 
              onBack={() => window.location.hash = ''}
              onDelete={handleDeleteReport}
              onUpdateStatus={handleUpdateStatus}
            />
          )}
          {view === AppView.SUCCESS && (
            <div className="max-w-md mx-auto text-center py-12">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-green-500/10 text-green-500 rounded-full mb-6 border border-green-500/20">
                <CheckCircle2 size={40} />
              </div>
              <h2 className="text-4xl font-black text-white mb-4 uppercase italic">Sent!</h2>
              <p className="text-slate-400 mb-10 text-lg">
                Will has been notified about <span className="text-red-600 font-bold">{lastReport?.itemName}</span>.
              </p>
              <button onClick={() => window.location.hash = ''} className="w-full bg-red-600 text-white font-black py-5 rounded-2xl">Return Home</button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
