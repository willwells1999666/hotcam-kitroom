
import React, { useEffect, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Share2, Printer, Copy, Check, ExternalLink } from 'lucide-react';

export const QRCodeGenerator: React.FC = () => {
  const [reportUrl, setReportUrl] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // This creates a robust link to the current domain + the /#/report route
    const baseUrl = window.location.href.split('#')[0].replace(/\/$/, '');
    const url = `${baseUrl}/#/report`;
    setReportUrl(url);
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(reportUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-md border border-white/10 rounded-[2.5rem] p-10 shadow-2xl flex flex-col items-center max-w-lg w-full">
      <div className="mb-8 text-center">
        <div className="inline-flex items-center justify-center w-12 h-12 bg-red-600/10 text-red-500 rounded-xl mb-4 border border-red-600/20">
          <ExternalLink size={24} />
        </div>
        <h2 className="text-2xl font-black text-white mb-2 uppercase tracking-tight">Warehouse Quick Access</h2>
        <p className="text-slate-400 font-medium text-sm">Print this and stick it on the warehouse door.</p>
      </div>

      <div className="bg-white p-6 rounded-3xl shadow-2xl mb-10 transition-all hover:scale-[1.05] duration-500 ring-8 ring-white/5">
        <QRCodeSVG 
          value={reportUrl} 
          size={220} 
          level="H"
          includeMargin={false}
          fgColor="#000000"
        />
      </div>

      <div className="w-full space-y-4">
        <div className="flex items-center gap-3 p-4 bg-black/40 rounded-2xl border border-white/5 group">
          <code className="text-[10px] text-slate-500 truncate flex-1 font-mono uppercase tracking-tighter">{reportUrl}</code>
          <button 
            onClick={handleCopy}
            className="text-slate-500 hover:text-red-500 transition-colors shrink-0"
            title="Copy URL"
          >
            {copied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={handlePrint}
            className="flex items-center justify-center gap-3 py-4 px-6 bg-white text-black hover:bg-red-600 hover:text-white rounded-2xl font-black uppercase tracking-widest transition-all active:scale-95 text-xs"
          >
            <Printer size={18} /> Print Label
          </button>
          <button 
            onClick={handleCopy}
            className="flex items-center justify-center gap-3 py-4 px-6 bg-white/5 hover:bg-white/10 text-white rounded-2xl font-black uppercase tracking-widest transition-all active:scale-95 border border-white/5 text-xs"
          >
            <Share2 size={18} /> Copy Link
          </button>
        </div>
      </div>
    </div>
  );
};
