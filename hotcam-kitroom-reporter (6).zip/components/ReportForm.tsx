
import React, { useState } from 'react';
import { KitReport } from '../types';
import { processReportWithGemini } from '../services/geminiService';
import { CONFIG } from '../constants';
import { Send, User, Package, Calendar, Loader2, ShieldCheck, AlertCircle } from 'lucide-react';

interface ReportFormProps {
  onSuccess: (report: KitReport) => void;
}

export const ReportForm: React.FC<ReportFormProps> = ({ onSuccess }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    itemName: '',
    userName: '',
    date: new Date().toISOString().split('T')[0]
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.itemName || !formData.userName) return;

    setLoading(true);
    setError(null);
    
    const newReport: KitReport = {
      id: Math.random().toString(36).substr(2, 9),
      ...formData,
      status: 'PENDING'
    };

    try {
      // 1. Try to get AI enrichment (optional)
      const geminiResult = await processReportWithGemini(newReport);

      // 2. Prepare email data
      const emailData: any = {
        _subject: `⚠️ KITROOM REPORT: ${formData.itemName}`,
        Item: formData.itemName,
        Reported_By: formData.userName,
        Date: formData.date,
        _template: "table"
      };

      // Add AI info only if available
      if (geminiResult) {
        emailData.AI_Summary = geminiResult.summary;
        emailData.Category = geminiResult.category;
      }

      // 3. Send email via FormSubmit
      const emailResponse = await fetch(`https://formsubmit.co/ajax/${CONFIG.EMAIL_RECEIVER}`, {
        method: "POST",
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(emailData)
      });

      if (!emailResponse.ok) throw new Error("Notification system temporarily offline");

      // 4. Save locally
      const existingReports = JSON.parse(localStorage.getItem('hotcam_reports') || '[]');
      localStorage.setItem('hotcam_reports', JSON.stringify([...existingReports, newReport]));

      setLoading(false);
      onSuccess(newReport);
    } catch (err) {
      console.error("Submission error", err);
      // Fallback: save locally even if email fails
      const existingReports = JSON.parse(localStorage.getItem('hotcam_reports') || '[]');
      localStorage.setItem('hotcam_reports', JSON.stringify([...existingReports, newReport]));
      setLoading(false);
      onSuccess(newReport);
    }
  };

  return (
    <div className="max-w-md w-full mx-auto p-10 bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-red-600" />
      
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-black text-white uppercase tracking-tighter italic">Submit Report</h1>
        <p className="text-slate-400 mt-2 font-medium">Will notify Logistics (Will Wells)</p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-600/10 border border-red-600/20 rounded-xl flex items-center gap-3 text-red-500 text-sm">
          <AlertCircle size={18} />
          <p>{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        <div>
          <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
            <Package size={14} className="text-red-500" /> Item / Consumable
          </label>
          <input
            required
            type="text"
            placeholder="e.g. 9V Batteries, Camera Tape..."
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white font-bold focus:outline-none focus:border-red-600 focus:bg-white/10 transition-all placeholder:text-slate-600"
            value={formData.itemName}
            onChange={(e) => setFormData(prev => ({ ...prev, itemName: e.target.value }))}
          />
        </div>

        <div>
          <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
            <User size={14} className="text-red-500" /> Your Name
          </label>
          <input
            required
            type="text"
            placeholder="Enter your name"
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white font-bold focus:outline-none focus:border-red-600 focus:bg-white/10 transition-all placeholder:text-slate-600"
            value={formData.userName}
            onChange={(e) => setFormData(prev => ({ ...prev, userName: e.target.value }))}
          />
        </div>

        <div>
          <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
            <Calendar size={14} className="text-red-500" /> Date
          </label>
          <input
            disabled
            type="date"
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-slate-500 font-bold cursor-not-allowed"
            value={formData.date}
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-red-600 hover:bg-white hover:text-black disabled:bg-slate-800 disabled:text-slate-500 text-white font-black py-5 rounded-2xl shadow-xl shadow-red-600/10 flex items-center justify-center gap-3 transition-all active:scale-95 uppercase tracking-widest"
        >
          {loading ? (
            <div className="flex items-center gap-2">
              <Loader2 className="animate-spin" size={20} />
              <span>Sending Report...</span>
            </div>
          ) : (
            <>
              <Send size={20} /> Send Report
            </>
          )}
        </button>
      </form>
      
      <div className="mt-8 flex items-center justify-center gap-2 py-3 px-4 bg-white/5 rounded-xl border border-white/5">
        <ShieldCheck size={14} className="text-green-500" />
        <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">
          Direct Notification System Active
        </p>
      </div>
    </div>
  );
};
