import React from 'react';
import { KitReport } from '../types';
import { Package, User, Calendar, ArrowLeft, Trash2, ChevronDown } from 'lucide-react';

interface ReportsListProps {
  reports: KitReport[];
  onBack: () => void;
  onDelete: (id: string) => void;
  onUpdateStatus: (id: string, status: KitReport['status']) => void;
}

export const ReportsList: React.FC<ReportsListProps> = ({ reports, onBack, onDelete, onUpdateStatus }) => {
  return (
    <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-10 gap-4">
        <div>
          <h1 className="text-4xl font-black text-white tracking-tighter uppercase italic drop-shadow-lg">Reports Board</h1>
          <p className="text-slate-400 font-medium">Log of reports</p>
        </div>
        <button 
          onClick={onBack}
          className="flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white hover:text-black text-white rounded-xl font-bold transition-all text-sm uppercase tracking-widest border border-white/10"
        >
          <ArrowLeft size={18} /> Back to Hub
        </button>
      </div>

      {reports.length === 0 ? (
        <div className="bg-black/20 border-2 border-dashed border-white/5 rounded-[2rem] p-20 text-center">
          <Package size={48} className="mx-auto mb-4 text-slate-700" />
          <p className="text-slate-500 font-bold uppercase tracking-widest">No reports logged yet.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {[...reports].reverse().map((report) => (
            <div 
              key={report.id} 
              className="glass-panel rounded-3xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 border-l-4 border-l-red-600 transition-all hover:bg-white/5"
            >
              <div className="flex items-start gap-4 flex-1">
                <div className="w-12 h-12 bg-red-600/10 rounded-2xl flex items-center justify-center text-red-500 shrink-0 border border-red-600/20">
                  <Package size={24} />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-xl font-black text-white uppercase tracking-tight truncate">{report.itemName}</h3>
                  <div className="flex flex-wrap gap-4 mt-2">
                    <span className="flex items-center gap-1.5 text-xs font-bold text-slate-400 uppercase tracking-widest">
                      <User size={12} className="text-red-500" /> {report.userName}
                    </span>
                    <span className="flex items-center gap-1.5 text-xs font-bold text-slate-400 uppercase tracking-widest">
                      <Calendar size={12} className="text-red-500" /> {report.date}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <div className="relative group/select">
                  <select
                    value={report.status}
                    onChange={(e) => onUpdateStatus(report.id, e.target.value as KitReport['status'])}
                    className="appearance-none bg-black/40 text-white text-[10px] font-black uppercase tracking-widest py-2.5 pl-4 pr-10 rounded-full border border-white/10 cursor-pointer hover:border-red-500 transition-colors focus:outline-none focus:ring-1 focus:ring-red-500"
                  >
                    <option value="PENDING" className="bg-slate-900">PENDING</option>
                    <option value="ORDERED" className="bg-slate-900">ORDERED</option>
                    <option value="RECEIVED" className="bg-slate-900">RECEIVED</option>
                  </select>
                  <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none group-hover/select:text-red-500" />
                </div>

                <button 
                  onClick={() => {
                    if (window.confirm(`Delete report for "${report.itemName}"?`)) {
                      onDelete(report.id);
                    }
                  }}
                  className="p-2.5 text-slate-600 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                  title="Delete submission"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};