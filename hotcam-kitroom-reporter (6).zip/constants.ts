
export const CONFIG = {
  EMAIL_RECEIVER: 'will.wells@hotcam.tv',
  COMPANY_NAME: 'Hotcam TV Kitroom',
};

export const SYSTEM_PROMPT = `Categorize the item (Camera, Audio, Lighting, Consumable, Grip) and provide a professional summary.`;
