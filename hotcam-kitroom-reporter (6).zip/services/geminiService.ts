
import { GoogleGenAI, Type } from "@google/genai";
import { KitReport } from "../types";
import { SYSTEM_PROMPT } from "../constants";

export const processReportWithGemini = async (report: KitReport): Promise<{ summary: string; category: string } | null> => {
  const apiKey = process.env.API_KEY;
  
  // If no API key is provided, return null. The form will handle this by using raw data.
  if (!apiKey || apiKey === 'undefined' || apiKey.length < 10) {
    return null;
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Report Details: Item: ${report.itemName}, User: ${report.userName}, Date: ${report.date}.`,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            category: { type: Type.STRING }
          },
          required: ["summary", "category"]
        }
      }
    });

    const text = response.text;
    if (!text) return null;

    const data = JSON.parse(text);
    return {
      summary: data.summary,
      category: data.category
    };
  } catch (error) {
    console.warn("Gemini optional processing skipped:", error);
    return null;
  }
};
