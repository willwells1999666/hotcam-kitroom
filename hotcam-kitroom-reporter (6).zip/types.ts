
export interface KitReport {
  id: string;
  itemName: string;
  userName: string;
  date: string;
  status: 'PENDING' | 'ORDERED' | 'RECEIVED';
}

export enum AppView {
  DASHBOARD = 'DASHBOARD',
  REPORT_FORM = 'REPORT_FORM',
  HISTORY = 'HISTORY',
  SUCCESS = 'SUCCESS'
}
